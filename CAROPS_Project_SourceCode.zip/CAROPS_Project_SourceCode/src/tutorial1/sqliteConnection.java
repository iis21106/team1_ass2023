package tutorial1;
//https://mvnrepository.com/artifact/org.xerial/sqlite-jdbc/3.8.7

import java.sql.*;
import javax.swing.*;

public class sqliteConnection {
	Connection conn = null;

	public static Connection dbConnector() {
		try {
			Class.forName("org.sqlite.JDBC");
			Connection conn = DriverManager
					.getConnection("jdbc:sqlite:C:\\Users\\olga\\eclipse-workspace\\tutorial1\\EmployeeData.db");
			//JOptionPane.showMessageDialog(null, "Connection Successful");
			return conn;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return null;
		}
	}
}
