package tutorial1;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

@SuppressWarnings("serial")
public class EntranceMechanicGUI extends JFrame {

	// DECLARE NOT-NORMAL VARIABLES
	private JTable table_vehicles;
	private JComboBox<String> comboBoxByModel_vehicles;
	private JTable table_services;
	private JTable table_envelopes;
	private String tmp_serviceName;
	private int tmp_estimatedPrice;
	private int tmp_total = 0;
	
	// DECLARE NORMAL VARIABLES
	private JTextField textField_vid;
	private JTextField textField_licensePlate;
	private JTextField textField_brand;
	private JTextField textField_year;
	private JTextField textField_engineDisplacement;
	private JTextField textField_payloadCapacity;
	private JTextField textField_model;
	private JTextField textField_searchVehicle;
	private JTextField textField_type;
	private JTextField textField_calculator;
	private JTextField textField_sid;
	private JTextField textField_serviceName;
	private JTextField textField_estimatedPrice;
	private JTextField textField_eid;
	private JTextField textField_vehicleid;
	private JTextField textField_eValue;
	private JTextField textField_eDays;

	// LAUNCHING THE APP
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EntranceMechanicGUI frame = new EntranceMechanicGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	Connection connection = null;

	// GETTERS AND SETTERS

	// MY-OWN CREATED METHODS
	public void refreshTableVehicles() {
		try {
			String query = "SELECT * FROM VEHICLES";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_vehicles.setModel(DbUtils.resultSetToTableModel(rs));

			pst.close();
			rs.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void refreshTableServices() {
		try {
			String query = "SELECT * FROM SERVICES";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_services.setModel(DbUtils.resultSetToTableModel(rs));

			pst.close();
			rs.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void refreshTableEnvelopes() {
		try {
			String query = "SELECT * FROM SERVICEENVELOPES";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_envelopes.setModel(DbUtils.resultSetToTableModel(rs));

			pst.close();
			rs.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void fillComboBoxVehicles() {
		try {
			String query = "SELECT * FROM VEHICLES";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				comboBoxByModel_vehicles.addItem(rs.getString("Model"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// CONSTRUCTOR
	public EntranceMechanicGUI() {

		connection = sqliteConnection.dbConnector();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1178, 683);
		setTitle("ΓΡΑΦΙΚΟ ΠΕΡΙΒΑΛΛΟΝ ΧΡΗΣΤΗ - ΜΗΧΑΝΙΚΟΣ ΥΠΟΔΟΧΗΣ");

		// JMENU APLA GIA FLEX
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);

		JMenuItem mntmNewMenuItem = new JMenuItem("Open");
		mnNewMenu.add(mntmNewMenuItem);

		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Exit");
		mnNewMenu.add(mntmNewMenuItem_1);

		JMenu mnNewMenu_1 = new JMenu("Edit");
		menuBar.add(mnNewMenu_1);

		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Undo");
		mnNewMenu_1.add(mntmNewMenuItem_2);
		getContentPane().setLayout(null);

		// ΚΑΡΤΕΛΑ ΚΑΤΑΧΩΡΙΣΗ ΣΤΟΙΧΕΙΩΝ
		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setBounds(10, 11, 1142, 600);
		getContentPane().add(tabbedPane_1);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.addTab("ΚΑΤΑΧΩΡΙΣΗ ΣΤΟΙΧΕΙΩΝ", null, tabbedPane, null);

		// ΚΑΡΤΕΛΑ ΑΝΑΖΗΤΗΣΗ ΟΧΗΜΑΤΟΣ
		JPanel panel_searchVehicle = new JPanel();
		tabbedPane.addTab("ΑΝΑΖΗΤΗΣΗ ΟΧΗΜΑΤΟΣ", null, panel_searchVehicle, null);
		panel_searchVehicle.setLayout(null);

		JLabel lbl_VID = new JLabel("VID:");
		lbl_VID.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_VID.setBounds(10, 105, 162, 25);
		panel_searchVehicle.add(lbl_VID);

		textField_vid = new JTextField();
		textField_vid.setColumns(10);
		textField_vid.setBounds(182, 103, 104, 25);
		panel_searchVehicle.add(textField_vid);

		JLabel lbl_LicensePlate = new JLabel("LicensePlate:");
		lbl_LicensePlate.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_LicensePlate.setBounds(10, 141, 162, 25);
		panel_searchVehicle.add(lbl_LicensePlate);

		textField_licensePlate = new JTextField();
		textField_licensePlate.setColumns(10);
		textField_licensePlate.setBounds(182, 139, 104, 25);
		panel_searchVehicle.add(textField_licensePlate);

		JLabel lbl_Brand = new JLabel("Brand:");
		lbl_Brand.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_Brand.setBounds(10, 175, 162, 25);
		panel_searchVehicle.add(lbl_Brand);

		textField_brand = new JTextField();
		textField_brand.setColumns(10);
		textField_brand.setBounds(182, 175, 104, 25);
		panel_searchVehicle.add(textField_brand);

		JLabel lbl_YearOfManufacturing = new JLabel("YearOfManufacturing:");
		lbl_YearOfManufacturing.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_YearOfManufacturing.setBounds(10, 247, 162, 25);
		panel_searchVehicle.add(lbl_YearOfManufacturing);

		textField_year = new JTextField();
		textField_year.setColumns(10);
		textField_year.setBounds(182, 247, 104, 25);
		panel_searchVehicle.add(textField_year);

		JLabel lbl_EngineDisplacement = new JLabel("EngineDisplacement:");
		lbl_EngineDisplacement.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_EngineDisplacement.setBounds(10, 283, 162, 25);
		panel_searchVehicle.add(lbl_EngineDisplacement);

		textField_engineDisplacement = new JTextField();
		textField_engineDisplacement.setColumns(10);
		textField_engineDisplacement.setBounds(182, 283, 104, 25);
		panel_searchVehicle.add(textField_engineDisplacement);

		JLabel lbl_PayloadCapasity = new JLabel("PayloadCapacity:");
		lbl_PayloadCapasity.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_PayloadCapasity.setBounds(10, 319, 162, 25);
		panel_searchVehicle.add(lbl_PayloadCapasity);

		textField_payloadCapacity = new JTextField();
		textField_payloadCapacity.setColumns(10);
		textField_payloadCapacity.setBounds(182, 319, 104, 25);
		panel_searchVehicle.add(textField_payloadCapacity);

		JLabel lbl_Model = new JLabel("Model:");
		lbl_Model.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_Model.setBounds(10, 211, 162, 25);
		panel_searchVehicle.add(lbl_Model);

		textField_model = new JTextField();
		textField_model.setColumns(10);
		textField_model.setBounds(182, 211, 104, 25);
		panel_searchVehicle.add(textField_model);

		JButton btnCreateVehicle = new JButton("Create Vehicle");
		btnCreateVehicle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "INSERT INTO VEHICLES (VID,LICENSEPLATE,BRAND,MODEL,YEAR,ENGINEDISPLACEMENT,PAYLOADCAPACITY,TYPE) VALUES (?,?,?,?,?,?,?,?)";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textField_vid.getText());
					pst.setString(2, textField_licensePlate.getText());
					pst.setString(3, textField_brand.getText());
					pst.setString(4, textField_model.getText());
					pst.setString(5, textField_year.getText());
					pst.setString(6, textField_engineDisplacement.getText());
					pst.setString(7, textField_payloadCapacity.getText());
					pst.setString(8, textField_type.getText());
					pst.execute();

					JOptionPane.showMessageDialog(null, "Vehicle Created");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableVehicles();

			}
		});
		btnCreateVehicle.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
		btnCreateVehicle.setBounds(98, 397, 188, 38);
		panel_searchVehicle.add(btnCreateVehicle);

		JButton btnEditVehicle = new JButton("Edit Vehicle");
		btnEditVehicle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "UPDATE VEHICLES SET VID='" + textField_vid.getText() + "' ,LICENSEPLATE='"
							+ textField_licensePlate.getText() + "' ,BRAND='" + textField_brand.getText() + "' ,MODEL='"
							+ textField_model.getText() + "', YEAR='" + textField_year.getText()
							+ "', ENGINEDISPLACEMENT='" + textField_engineDisplacement.getText()
							+ "' ,PAYLOADCAPACITY='" + textField_payloadCapacity.getText() + "' ,TYPE='"
							+ textField_type.getText() + "'  " + "WHERE VID = '" + textField_vid.getText() + "' ";
					PreparedStatement pst = connection.prepareStatement(query);

					pst.execute();

					JOptionPane.showMessageDialog(null, "Vehicle Data Updated");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableVehicles();

			}
		});
		btnEditVehicle.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
		btnEditVehicle.setBounds(98, 446, 188, 38);
		panel_searchVehicle.add(btnEditVehicle);

		JButton btnDeleteVehicle = new JButton("Delete Vehicle");
		btnDeleteVehicle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "DELETE FROM VEHICLES WHERE VID='" + textField_vid.getText() + "'  ";
					PreparedStatement pst = connection.prepareStatement(query);

					pst.execute();

					JOptionPane.showMessageDialog(null, "Vehicle Deleted");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableVehicles();

			}
		});
		btnDeleteVehicle.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
		btnDeleteVehicle.setBounds(98, 495, 188, 38);
		panel_searchVehicle.add(btnDeleteVehicle);

		// JSCROLLPANE & JTABLE
		JScrollPane scrollPane_vehicles = new JScrollPane();
		scrollPane_vehicles.setBounds(296, 102, 825, 186);
		panel_searchVehicle.add(scrollPane_vehicles);

		table_vehicles = new JTable();
		table_vehicles.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				try {
					int row = table_vehicles.getSelectedRow();
					DefaultTableModel model = (DefaultTableModel) table_vehicles.getModel();
					textField_vid.setText(model.getValueAt(row, 0).toString());
					textField_licensePlate.setText(model.getValueAt(row, 1).toString());
					textField_brand.setText(model.getValueAt(row, 2).toString());
					textField_model.setText(model.getValueAt(row, 3).toString());
					textField_year.setText(model.getValueAt(row, 4).toString());
					textField_engineDisplacement.setText(model.getValueAt(row, 5).toString());
					textField_payloadCapacity.setText(model.getValueAt(row, 6).toString());
					textField_type.setText(model.getValueAt(row, 7).toString());
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});
		scrollPane_vehicles.setViewportView(table_vehicles);

		// JCOMBOBOX
		comboBoxByModel_vehicles = new JComboBox<String>();
		comboBoxByModel_vehicles.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {

					String query = "SELECT * FROM VEHICLES WHERE MODEL=?";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, (String) comboBoxByModel_vehicles.getSelectedItem());
					ResultSet rs = pst.executeQuery();
					while (rs.next()) {
						textField_vid.setText(rs.getString("VID"));
						textField_licensePlate.setText(rs.getString("LicensePlate"));
						textField_brand.setText(rs.getString("Brand"));
						textField_model.setText(rs.getString("Model"));
						textField_year.setText(rs.getString("Year"));
						textField_engineDisplacement.setText(rs.getString("EngineDisplacement"));
						textField_payloadCapacity.setText(rs.getString("PayloadCapacity"));
						textField_type.setText(rs.getString("Type"));
					}

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});
		comboBoxByModel_vehicles.setBounds(10, 37, 276, 57);
		panel_searchVehicle.add(comboBoxByModel_vehicles);

		textField_searchVehicle = new JTextField();
		textField_searchVehicle.setForeground(new Color(51, 204, 204));
		textField_searchVehicle.setText("Αναζήτηση Οχήματος με Αριθμό Πινακίδας");
		textField_searchVehicle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				try {

					String query = "SELECT * FROM VEHICLES WHERE LICENSEPLATE=?";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textField_searchVehicle.getText());
					ResultSet rs = pst.executeQuery();

					table_vehicles.setModel(DbUtils.resultSetToTableModel(rs));

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});
		textField_searchVehicle.setBounds(815, 41, 306, 49);
		panel_searchVehicle.add(textField_searchVehicle);
		textField_searchVehicle.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel(
				"<html>\r\nΠληκτρολογήστε ολόκληρο το license<br>\r\nplate και θα βρείτε αυτό που ψάχνετε:\r\n</html>");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(582, 34, 224, 57);
		panel_searchVehicle.add(lblNewLabel_3);

		JLabel lbl_type = new JLabel("Type:");
		lbl_type.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_type.setBounds(10, 355, 162, 25);
		panel_searchVehicle.add(lbl_type);

		textField_type = new JTextField();
		textField_type.setColumns(10);
		textField_type.setBounds(182, 355, 104, 25);
		panel_searchVehicle.add(textField_type);

		// ΟΠΤΙΚΟΣ ΕΛΕΓΧΟΣ & ΔΟΚΙΜΗ ΟΧΗΜΑΤΟΣ
		JTabbedPane tabbedPane_2 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.addTab("ΟΠΤΙΚΟΣ ΕΛΕΓΧΟΣ & ΔΟΚΙΜΗ ΟΧΗΜΑΤΟΣ", null, tabbedPane_2, null);

		DefaultListModel<String> dlm_services = new DefaultListModel<String>();

		// ΚΑΤΑΓΡΑΦΗ ΕΡΓΑΣΙΩΝ
		JPanel panel_services = new JPanel();
		tabbedPane_2.addTab("ΚΑΤΑΓΡΑΦΗ ΕΡΓΑΣΙΩΝ", null, panel_services, null);
		panel_services.setLayout(null);

		JList<String> list = new JList<String>();
		list.setToolTipText("");
		list.setBounds(662, 44, 285, 227);
		panel_services.add(list);

		textField_calculator = new JTextField();
		textField_calculator.setHorizontalAlignment(SwingConstants.CENTER);
		textField_calculator.setText("0,00");
		textField_calculator.setBounds(822, 282, 125, 33);
		panel_services.add(textField_calculator);
		textField_calculator.setColumns(10);

		// JSCROLLPANE & JTABLE DATA
		JScrollPane scrollPane_services = new JScrollPane();
		scrollPane_services.setBounds(10, 44, 629, 309);
		panel_services.add(scrollPane_services);

		table_services = new JTable();
		table_services.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					int row = table_services.getSelectedRow();
					DefaultTableModel model_s = (DefaultTableModel) table_services.getModel();
					textField_sid.setText(model_s.getValueAt(row, 0).toString());
					textField_serviceName.setText(model_s.getValueAt(row, 1).toString());
					textField_estimatedPrice.setText(model_s.getValueAt(row, 2).toString());

					tmp_serviceName = model_s.getValueAt(row, 1).toString();
					tmp_estimatedPrice = Integer.parseInt(model_s.getValueAt(row, 2).toString());
				} catch (Exception e) {
					e.printStackTrace();

				}
			}
		});
		scrollPane_services.setViewportView(table_services);

		JLabel lbl_sid = new JLabel("Service_id (SID):");
		lbl_sid.setBounds(10, 430, 116, 14);
		panel_services.add(lbl_sid);

		textField_sid = new JTextField();
		textField_sid.setBounds(136, 430, 259, 20);
		panel_services.add(textField_sid);
		textField_sid.setColumns(10);

		textField_serviceName = new JTextField();
		textField_serviceName.setColumns(10);
		textField_serviceName.setBounds(136, 461, 259, 20);
		panel_services.add(textField_serviceName);

		textField_estimatedPrice = new JTextField();
		textField_estimatedPrice.setColumns(10);
		textField_estimatedPrice.setBounds(136, 489, 259, 20);
		panel_services.add(textField_estimatedPrice);

		JLabel lbl_serviceName = new JLabel("Service Name:");
		lbl_serviceName.setBounds(10, 461, 116, 14);
		panel_services.add(lbl_serviceName);

		JLabel lbl_estimatedPrice = new JLabel("Estimated Price:");
		lbl_estimatedPrice.setBounds(10, 489, 116, 14);
		panel_services.add(lbl_estimatedPrice);
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				dlm_services.addElement(tmp_serviceName);
				list.setModel(dlm_services);

				tmp_total += tmp_estimatedPrice;
				textField_calculator.setText(Integer.toString(tmp_total));
			}
		});
		btnNewButton.setBounds(405, 429, 234, 80);
		panel_services.add(btnNewButton);

		JLabel lblNewLabel = new JLabel("€");
		lblNewLabel.setBounds(957, 291, 46, 14);
		panel_services.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Λίστα με τις διαθέσιμες υποστηριζόμενες εργασίες επισκευής:");
		lblNewLabel_1.setBounds(10, 11, 629, 20);
		panel_services.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Οι εργασίες επισκευής που θα χρειαστούν για την επιδιόρθωση του οχήματος:");
		lblNewLabel_2.setBounds(662, 5, 460, 33);
		panel_services.add(lblNewLabel_2);

		JPanel panel_envelopes = new JPanel();
		tabbedPane_2.addTab("ΦΑΚΕΛΟΙ ΕΠΙΣΚΕΥΗΣ", null, panel_envelopes, null);
		panel_envelopes.setLayout(null);

		//JSCROLLPANE & JTABLE DATA
		JScrollPane scrollPane_envelopes = new JScrollPane();
		scrollPane_envelopes.setBounds(573, 113, 361, 246);
		panel_envelopes.add(scrollPane_envelopes);
		
		table_envelopes = new JTable();
		scrollPane_envelopes.setViewportView(table_envelopes);

		JLabel lbl_sid_1 = new JLabel("Envelope_id (EID):");
		lbl_sid_1.setBounds(30, 113, 116, 14);
		panel_envelopes.add(lbl_sid_1);

		textField_eid = new JTextField();
		textField_eid.setColumns(10);
		textField_eid.setBounds(156, 113, 259, 20);
		panel_envelopes.add(textField_eid);

		JLabel lbl_sid_2 = new JLabel("Vehicle_id(VID):");
		lbl_sid_2.setBounds(30, 197, 116, 14);
		panel_envelopes.add(lbl_sid_2);

		textField_vehicleid = new JTextField();
		textField_vehicleid.setColumns(10);
		textField_vehicleid.setBounds(156, 197, 259, 20);
		panel_envelopes.add(textField_vehicleid);

		JLabel lbl_sid_3 = new JLabel("Estimated Value :");
		lbl_sid_3.setBounds(30, 282, 116, 14);
		panel_envelopes.add(lbl_sid_3);

		textField_eValue = new JTextField();
		textField_eValue.setColumns(10);
		textField_eValue.setBounds(156, 282, 259, 20);
		panel_envelopes.add(textField_eValue);

		JLabel lbl_sid_4 = new JLabel("Estimated Days:");
		lbl_sid_4.setBounds(30, 361, 116, 14);
		panel_envelopes.add(lbl_sid_4);

		textField_eDays = new JTextField();
		textField_eDays.setColumns(10);
		textField_eDays.setBounds(156, 361, 259, 20);
		panel_envelopes.add(textField_eDays);

		JButton btn_createEnv = new JButton("Υποβολή Φακέλου");
		btn_createEnv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "INSERT INTO SERVICEENVELOPES (EID,VID,ESTIMATEDVALUE,ESTIMATEDDAYS) VALUES (?,?,?,?)";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textField_eid.getText());
					pst.setString(2, textField_vehicleid.getText());
					pst.setString(3, textField_eValue.getText());
					pst.setString(4, textField_eDays.getText());
					pst.execute();

					JOptionPane.showMessageDialog(null, "ΦΑΚΕΛΟΣ ΕΠΙΣΚΕΥΗΣ, ΕΠΙΤΥΧΗΣ ΔΗΜΙΟΥΡΓΙΑ");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableEnvelopes();

			}
		});
		btn_createEnv.setBounds(10, 478, 175, 48);
		panel_envelopes.add(btn_createEnv);

		JButton btn_editEnv = new JButton("Edit Envelope");
		btn_editEnv.setBounds(195, 478, 140, 23);
		panel_envelopes.add(btn_editEnv);

		JButton btn_delEnv = new JButton("Delete Envelope");
		btn_delEnv.setBounds(345, 478, 133, 23);
		panel_envelopes.add(btn_delEnv);
		
		JLabel lblNewLabel_4 = new JLabel("δεν υλοποιήσαμε ακόμα τα κουμπιά edit και delete");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(195, 512, 292, 14);
		panel_envelopes.add(lblNewLabel_4);

		JTabbedPane tabbedPane_3 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.addTab("New tab", null, tabbedPane_3, null);

		JPanel panel_4 = new JPanel();
		tabbedPane_3.addTab("New tab", null, panel_4, null);
		panel_4.setLayout(null);

		refreshTableVehicles();
		fillComboBoxVehicles();
		refreshTableServices();
		refreshTableEnvelopes();

	}
}
