package tutorial1;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

@SuppressWarnings("serial")
public class SecretaryGUI extends JFrame {

	// DECLARE NOT-NORMAL VARIABLES
	private JFrame frame;
	private JPanel contentPane;
	private JTable table_customers;
	private JTable table_vehicles;
	private JTable table_appointments;
	private JTable table_envelopes;
	private JComboBox<String> comboBoxByName_customers;
	private JComboBox<String> comboBoxByModel_vehicles;
	JTabbedPane tabbedPane2;

	// LAUNCH THE APP
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SecretaryGUI frame = new SecretaryGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	Connection connection = null;

	// DECLARE NORMAL VARIABLES
	private JTextField textField_CID;
	private JLabel lbl_Name;
	private JLabel lbl_Surname;
	private JLabel lbl_Tel;
	private JTextField textField_Name;
	private JTextField textField_Surname;
	private JTextField textField_Tel;
	private JButton btnEditCustomer;
	private JButton btnDeleteCustomer;
	private JTabbedPane tabbedPane_1;
	private JPanel panel_createAppointment;
	private JTabbedPane tabbedPane_5;
	private JPanel panel_grammateiaEnvs;
	private JTextField textField_Address;
	private JTextField textField_Email;
	private JTextField textField_VID;
	private JTextField textField_LicensePlate;
	private JTextField textField_Brand;
	private JTextField textField_Year;
	private JTextField textField_EngineDisplacement;
	private JTextField textField_PayloadCapacity;
	private JTextField textField_Model;
	private JLabel lbl_aid;
	private JTextField textField_aid;
	private JLabel lbl_cid;
	private JTextField textField_cid;
	private JLabel lbl_vid;
	private JTextField textField_vid;
	private JLabel lbl_dateNtime;
	private JTextField textField_dateNtime;
	private JButton btnCreateAppointment;
	private JButton btnEditAppointment;
	private JButton btnDeleteAppointment;
	private JComboBox<String> comboBoxByAID_appointments;
	private JScrollPane scrollPane_appointments;
	private JLabel lbl_Type;
	private JTextField textField_Type;

	// MY-OWN CREATED METHODS
	public void refreshTableCustomers() {
		try {
			String query = "SELECT * FROM CUSTOMERS";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_customers.setModel(DbUtils.resultSetToTableModel(rs));

			pst.close();
			rs.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void refreshTableVehicles() {
		try {
			String query = "SELECT * FROM VEHICLES";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_vehicles.setModel(DbUtils.resultSetToTableModel(rs));

			pst.close();
			rs.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void refreshTableAppointments() {
		try {
			String query = "SELECT * FROM APPOINTMENTS";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_appointments.setModel(DbUtils.resultSetToTableModel(rs));

			pst.close();
			rs.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void refreshTableEnvelopes() {
		try {
			String query = "SELECT * FROM SERVICEENVELOPES";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_envelopes.setModel(DbUtils.resultSetToTableModel(rs));

			pst.close();
			rs.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void fillComboBoxCustomers() {
		try {
			String query = "SELECT * FROM CUSTOMERS";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				comboBoxByName_customers.addItem(rs.getString("Name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void fillComboBoxVehicles() {
		try {
			String query = "SELECT * FROM VEHICLES";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				comboBoxByModel_vehicles.addItem(rs.getString("Model"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void fillComboBoxAppointments() {
		try {
			String query = "SELECT * FROM APPOINTMENTS";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				comboBoxByAID_appointments.addItem(rs.getString("AID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// CONSTRUCTOR
	public SecretaryGUI() {
		frame = new JFrame();
		connection = sqliteConnection.dbConnector();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1177, 683);
		setTitle("ΓΡΑΦΙΚΟ ΠΕΡΙΒΑΛΛΟΝ ΧΡΗΣΤΗ - ΓΡΑΜΜΑΤΕΙΑ");
		
		// MENU ON TOP
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);

		JMenuItem mntmNewMenuItem = new JMenuItem("Exit");
		mnNewMenu.add(mntmNewMenuItem);

		JMenu mnNewMenu_1 = new JMenu("Edit");
		menuBar.add(mnNewMenu_1);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		// 1.ΚΑΡΤΕΛΕΣ
		tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setBounds(10, 11, 1141, 599);
		contentPane.add(tabbedPane_1);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.addTab("ΚΑΡΤΕΛΕΣ", null, tabbedPane, null);

		// 1.1.ΔΗΜΙΟΥΡΓΙΑ ΚΑΡΤΕΛΑΣ ΠΕΛΑΤΗ
		JPanel panel_createCustomer = new JPanel();
		tabbedPane.addTab("ΔΗΜΙΟΥΡΓΙΑ ΚΑΡΤΕΛΑΣ ΠΕΛΑΤΗ", null, panel_createCustomer, null);
		panel_createCustomer.setLayout(null);

		// JLABELS
		JLabel lbl_CID = new JLabel("CID:");
		lbl_CID.setBounds(10, 104, 63, 25);
		panel_createCustomer.add(lbl_CID);
		lbl_CID.setFont(new Font("Tahoma", Font.PLAIN, 16));

		lbl_Name = new JLabel("Name:");
		lbl_Name.setBounds(10, 140, 63, 25);
		panel_createCustomer.add(lbl_Name);
		lbl_Name.setFont(new Font("Tahoma", Font.PLAIN, 16));

		lbl_Surname = new JLabel("Surname:");
		lbl_Surname.setBounds(10, 174, 74, 25);
		panel_createCustomer.add(lbl_Surname);
		lbl_Surname.setFont(new Font("Tahoma", Font.PLAIN, 16));

		lbl_Tel = new JLabel("Tel:");
		lbl_Tel.setBounds(10, 210, 63, 25);
		panel_createCustomer.add(lbl_Tel);
		lbl_Tel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		JLabel lbl_Address = new JLabel("Address:");
		lbl_Address.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_Address.setBounds(10, 246, 74, 25);
		panel_createCustomer.add(lbl_Address);

		JLabel lbl_Email = new JLabel("Email:");
		lbl_Email.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_Email.setBounds(10, 282, 63, 25);
		panel_createCustomer.add(lbl_Email);

		// JTEXTFIELDS
		textField_CID = new JTextField();
		textField_CID.setBounds(94, 104, 159, 25);
		panel_createCustomer.add(textField_CID);
		textField_CID.setColumns(10);

		textField_Name = new JTextField();
		textField_Name.setBounds(94, 140, 159, 25);
		panel_createCustomer.add(textField_Name);
		textField_Name.setColumns(10);

		textField_Surname = new JTextField();
		textField_Surname.setBounds(94, 176, 159, 25);
		panel_createCustomer.add(textField_Surname);
		textField_Surname.setColumns(10);

		textField_Tel = new JTextField();
		textField_Tel.setBounds(94, 212, 159, 25);
		panel_createCustomer.add(textField_Tel);
		textField_Tel.setColumns(10);
		
		textField_Address = new JTextField();
		textField_Address.setColumns(10);
		textField_Address.setBounds(94, 248, 159, 25);
		panel_createCustomer.add(textField_Address);

		textField_Email = new JTextField();
		textField_Email.setColumns(10);
		textField_Email.setBounds(94, 284, 159, 25);
		panel_createCustomer.add(textField_Email);

		// CREATE CUSTOMER BUTTON
		JButton btnCreateCustomer = new JButton("Create Customer");
		btnCreateCustomer.setBounds(65, 396, 188, 38);
		panel_createCustomer.add(btnCreateCustomer);
		btnCreateCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				try {
					String query = "INSERT INTO CUSTOMERS (CID,NAME,SURNAME,TEL,ADDRESS,EMAIL) VALUES (?,?,?,?,?,?)";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textField_CID.getText());
					pst.setString(2, textField_Name.getText());
					pst.setString(3, textField_Surname.getText());
					pst.setString(4, textField_Tel.getText());
					pst.setString(5, textField_Address.getText());
					pst.setString(6, textField_Email.getText());
					pst.execute();

					JOptionPane.showMessageDialog(null, "Customer Created");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableCustomers();
			}
		});
		btnCreateCustomer.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));

		// EDIT CUSTOMER BUTTON
		btnEditCustomer = new JButton("Edit Customer");
		btnEditCustomer.setBounds(65, 445, 188, 38);
		panel_createCustomer.add(btnEditCustomer);
		btnEditCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				try {
					String query = "UPDATE CUSTOMERS SET CID='" + textField_CID.getText() + "' ,NAME='"
							+ textField_Name.getText() + "' ,SURNAME='" + textField_Surname.getText() + "' ,TEL='"
							+ textField_Tel.getText() + "', ADDRESS='" + textField_Address.getText() + "', EMAIL='"
							+ textField_Email.getText() + "' " + "WHERE CID='" + textField_CID.getText() + "'   ";
					PreparedStatement pst = connection.prepareStatement(query);

					pst.execute();

					JOptionPane.showMessageDialog(null, "Customer Data Updated");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableCustomers();
			}
		});
		btnEditCustomer.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));

		// DELETE BUTTON
		btnDeleteCustomer = new JButton("Delete Customer");
		btnDeleteCustomer.setBounds(65, 494, 188, 38);
		panel_createCustomer.add(btnDeleteCustomer);
		btnDeleteCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				try {
					String query = "DELETE FROM CUSTOMERS WHERE CID='" + textField_CID.getText() + "'  ";
					PreparedStatement pst = connection.prepareStatement(query);

					pst.execute();

					JOptionPane.showMessageDialog(null, "Customer Deleted");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableCustomers();
			}
		});
		btnDeleteCustomer.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));

		//JTable
		JScrollPane scrollPane_customers = new JScrollPane();
		scrollPane_customers.setBounds(263, 104, 858, 242);
		panel_createCustomer.add(scrollPane_customers);

		table_customers = new JTable();
		table_customers.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					int row = table_customers.getSelectedRow();
					DefaultTableModel model = (DefaultTableModel) table_customers.getModel();
					textField_cid.setText(model.getValueAt(row, 0).toString());
					textField_Name.setText(model.getValueAt(row, 1).toString());
					textField_Surname.setText(model.getValueAt(row, 2).toString());
					textField_Tel.setText(model.getValueAt(row, 3).toString());
					textField_Address.setText(model.getValueAt(row, 4).toString());
					textField_Email.setText(model.getValueAt(row, 5).toString());
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});
		scrollPane_customers.setViewportView(table_customers);

		//JCOMBOBOX BY NAME FOR VEHICLES
		comboBoxByName_customers = new JComboBox<String>();
		comboBoxByName_customers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "SELECT * FROM CUSTOMERS WHERE NAME=?";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, (String) comboBoxByName_customers.getSelectedItem());
					ResultSet rs = pst.executeQuery();

					while (rs.next()) {
						textField_CID.setText(rs.getString("CID"));
						textField_Name.setText(rs.getString("Name"));
						textField_Surname.setText(rs.getString("Surname"));
						textField_Tel.setText(rs.getString("Tel"));
						textField_Address.setText(rs.getString("Address"));
						textField_Email.setText(rs.getString("Email"));
					}

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});
		comboBoxByName_customers.setBounds(10, 36, 243, 57);
		panel_createCustomer.add(comboBoxByName_customers);

		JButton btnLoadTable = new JButton("Load/Refresh Customers Data");
		btnLoadTable.setForeground(SystemColor.desktop);
		btnLoadTable.setBounds(840, 70, 281, 23);
		panel_createCustomer.add(btnLoadTable);

		// 1.2.ΔΗΜΙΟΥΡΓΙΑ ΚΑΡΤΕΛΑΣ ΟΧΗΜΑΤΟΣ
		JPanel panel_createVehicle = new JPanel();
		tabbedPane.addTab("ΔΗΜΙΟΥΡΓΙΑ ΚΑΡΤΕΛΑΣ ΟΧΗΜΑΤΟΣ", null, panel_createVehicle, null);
		panel_createVehicle.setLayout(null);
		
		//JLABELS & JTEXTFIELDS
		JLabel lbl_VID = new JLabel("VID:");
		lbl_VID.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_VID.setBounds(10, 104, 162, 25);
		panel_createVehicle.add(lbl_VID);
		
		textField_VID = new JTextField();
		textField_VID.setColumns(10);
		textField_VID.setBounds(182, 102, 104, 25);
		panel_createVehicle.add(textField_VID);
		
		JLabel lbl_LicensePlate = new JLabel("LicensePlate:");
		lbl_LicensePlate.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_LicensePlate.setBounds(10, 140, 162, 25);
		panel_createVehicle.add(lbl_LicensePlate);
		
		textField_LicensePlate = new JTextField();
		textField_LicensePlate.setColumns(10);
		textField_LicensePlate.setBounds(182, 138, 104, 25);
		panel_createVehicle.add(textField_LicensePlate);
		
		JLabel lbl_Brand = new JLabel("Brand:");
		lbl_Brand.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_Brand.setBounds(10, 174, 162, 25);
		panel_createVehicle.add(lbl_Brand);
		
		textField_Brand = new JTextField();
		textField_Brand.setColumns(10);
		textField_Brand.setBounds(182, 174, 104, 25);
		panel_createVehicle.add(textField_Brand);
		
		JLabel lbl_YearOfManufacturing = new JLabel("YearOfManufacturing:");
		lbl_YearOfManufacturing.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_YearOfManufacturing.setBounds(10, 246, 162, 25);
		panel_createVehicle.add(lbl_YearOfManufacturing);
		
		textField_Year = new JTextField();
		textField_Year.setColumns(10);
		textField_Year.setBounds(182, 246, 104, 25);
		panel_createVehicle.add(textField_Year);
		
		JLabel lbl_EngineDisplacement = new JLabel("EngineDisplacement:");
		lbl_EngineDisplacement.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_EngineDisplacement.setBounds(10, 282, 162, 25);
		panel_createVehicle.add(lbl_EngineDisplacement);
		
		textField_EngineDisplacement = new JTextField();
		textField_EngineDisplacement.setColumns(10);
		textField_EngineDisplacement.setBounds(182, 282, 104, 25);
		panel_createVehicle.add(textField_EngineDisplacement);
		
		JLabel lbl_PayloadCapasity = new JLabel("PayloadCapacity:");
		lbl_PayloadCapasity.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_PayloadCapasity.setBounds(10, 318, 162, 25);
		panel_createVehicle.add(lbl_PayloadCapasity);
		
		textField_PayloadCapacity = new JTextField();
		textField_PayloadCapacity.setColumns(10);
		textField_PayloadCapacity.setBounds(182, 318, 104, 25);
		panel_createVehicle.add(textField_PayloadCapacity);
		
		JLabel lbl_Model = new JLabel("Model:");
		lbl_Model.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_Model.setBounds(10, 210, 162, 25);
		panel_createVehicle.add(lbl_Model);
		
		textField_Model = new JTextField();
		textField_Model.setColumns(10);
		textField_Model.setBounds(182, 210, 104, 25);
		panel_createVehicle.add(textField_Model);
		
		//CREATE VEHICLE BUTTON
		JButton btnCreateVehicle = new JButton("Create Vehicle");
		btnCreateVehicle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "INSERT INTO VEHICLES (VID,LICENSEPLATE,BRAND,MODEL,YEAR,ENGINEDISPLACEMENT,PAYLOADCAPACITY,TYPE) VALUES (?,?,?,?,?,?,?,?)";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textField_VID.getText());
					pst.setString(2, textField_LicensePlate.getText());
					pst.setString(3, textField_Brand.getText());
					pst.setString(4, textField_Model.getText());
					pst.setString(5, textField_Year.getText());
					pst.setString(6, textField_EngineDisplacement.getText());
					pst.setString(7, textField_PayloadCapacity.getText());
					pst.setString(8, textField_Type.getText());
					pst.execute();

					JOptionPane.showMessageDialog(null, "Vehicle Created");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableVehicles();
			}
		});
		btnCreateVehicle.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
		btnCreateVehicle.setBounds(98, 396, 188, 38);
		panel_createVehicle.add(btnCreateVehicle);

		//EDIT VEHICLE BUTTON
		JButton btnEditVehicle = new JButton("Edit Vehicle");
		btnEditVehicle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "UPDATE VEHICLES SET VID='" + textField_VID.getText() + "' ,LICENSEPLATE='"
							+ textField_LicensePlate.getText() + "' ,BRAND='" + textField_Brand.getText() + "' ,MODEL='"
							+ textField_Model.getText() + "', YEAR='" + textField_Year.getText()
							+ "', ENGINEDISPLACEMENT='" + textField_EngineDisplacement.getText()
							+ "' ,PAYLOADCAPACITY='" + textField_PayloadCapacity.getText() + "', TYPE='"+textField_Type.getText()+"' " + "WHERE VID = '"
							+ textField_VID.getText() + "' ";
					PreparedStatement pst = connection.prepareStatement(query);

					pst.execute();

					JOptionPane.showMessageDialog(null, "Vehicle Data Updated");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableVehicles();
			}
		});
		btnEditVehicle.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
		btnEditVehicle.setBounds(98, 445, 188, 38);
		panel_createVehicle.add(btnEditVehicle);

		//DELETE VEHICLE BUTTON
		JButton btnDeleteVehicle = new JButton("Delete Vehicle");
		btnDeleteVehicle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "DELETE FROM VEHICLES WHERE VID='" + textField_VID.getText() + "'  ";
					PreparedStatement pst = connection.prepareStatement(query);

					pst.execute();

					JOptionPane.showMessageDialog(null, "Vehicle Deleted");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableVehicles();
			}
		});
		btnDeleteVehicle.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
		btnDeleteVehicle.setBounds(98, 494, 188, 38);
		panel_createVehicle.add(btnDeleteVehicle);
		
		//JTABLE
		JScrollPane scrollPane_vehicles = new JScrollPane();
		scrollPane_vehicles.setBounds(296, 101, 825, 187);
		panel_createVehicle.add(scrollPane_vehicles);
		
		table_vehicles = new JTable();
		table_vehicles.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					int row = table_vehicles.getSelectedRow();
					DefaultTableModel model = (DefaultTableModel) table_vehicles.getModel();
					textField_vid.setText(model.getValueAt(row, 0).toString());
					textField_LicensePlate.setText(model.getValueAt(row, 1).toString());
					textField_Brand.setText(model.getValueAt(row, 2).toString());
					textField_Model.setText(model.getValueAt(row, 3).toString());
					textField_Year.setText(model.getValueAt(row, 4).toString());
					textField_EngineDisplacement.setText(model.getValueAt(row, 5).toString());
					textField_PayloadCapacity.setText(model.getValueAt(row, 6).toString());
					textField_Type.setText(model.getValueAt(row, 7).toString());
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});
		scrollPane_vehicles.setViewportView(table_vehicles);
		
		//JCOMBOBOX BY MODEL FOR VEHICLES
		comboBoxByModel_vehicles = new JComboBox<String>();
		comboBoxByModel_vehicles.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {

					String query = "SELECT * FROM VEHICLES WHERE MODEL=?";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, (String) comboBoxByModel_vehicles.getSelectedItem());
					ResultSet rs = pst.executeQuery();
					while (rs.next()) {
						textField_VID.setText(rs.getString("VID"));
						textField_LicensePlate.setText(rs.getString("LicensePlate"));
						textField_Brand.setText(rs.getString("Brand"));
						textField_Model.setText(rs.getString("Model"));
						textField_Year.setText(rs.getString("Year"));
						textField_EngineDisplacement.setText(rs.getString("EngineDisplacement"));
						textField_PayloadCapacity.setText(rs.getString("PayloadCapacity"));
						textField_Type.setText(rs.getString("Type"));
					}

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

		comboBoxByModel_vehicles.setBounds(10, 36, 276, 57);
		panel_createVehicle.add(comboBoxByModel_vehicles);
		
		lbl_Type = new JLabel("Type:");
		lbl_Type.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lbl_Type.setBounds(10, 354, 162, 25);
		panel_createVehicle.add(lbl_Type);
		
		textField_Type = new JTextField();
		textField_Type.setColumns(10);
		textField_Type.setBounds(182, 354, 104, 25);
		panel_createVehicle.add(textField_Type);
		

		// ΡΑΝΤΕΒΟΥ

		JTabbedPane tabbedPane_3 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.addTab("ΡΑΝΤΕΒΟΥ", null, tabbedPane_3, null);

		panel_createAppointment = new JPanel();
		tabbedPane_3.addTab("ΔΗΜΙΟΥΡΓΙΑ ΡΑΝΤΕΒΟΥ", null, panel_createAppointment, null);
		panel_createAppointment.setLayout(null);
		
		//JTABS & JTEXTFIELDS
		lbl_aid = new JLabel("Appointment_id (aid):");
		lbl_aid.setBounds(10, 104, 162, 25);
		lbl_aid.setFont(new Font("Tahoma", Font.PLAIN, 16));
		panel_createAppointment.add(lbl_aid);
		
		textField_aid = new JTextField();
		textField_aid.setBounds(182, 102, 152, 25);
		textField_aid.setColumns(10);
		panel_createAppointment.add(textField_aid);
		
		lbl_cid = new JLabel("Customer_ID (cid):");
		lbl_cid.setBounds(10, 140, 162, 25);
		lbl_cid.setFont(new Font("Tahoma", Font.PLAIN, 16));
		panel_createAppointment.add(lbl_cid);
		
		textField_cid = new JTextField();
		textField_cid.setBounds(182, 138, 152, 25);
		textField_cid.setColumns(10);
		panel_createAppointment.add(textField_cid);
		
		lbl_vid = new JLabel("Vehicle_ID (vid):");
		lbl_vid.setBounds(10, 174, 162, 25);
		lbl_vid.setFont(new Font("Tahoma", Font.PLAIN, 16));
		panel_createAppointment.add(lbl_vid);
		
		textField_vid = new JTextField();
		textField_vid.setBounds(182, 174, 152, 25);
		textField_vid.setColumns(10);
		panel_createAppointment.add(textField_vid);
		
		lbl_dateNtime = new JLabel("Date & Time:");
		lbl_dateNtime.setBounds(10, 210, 162, 25);
		lbl_dateNtime.setFont(new Font("Tahoma", Font.PLAIN, 16));
		panel_createAppointment.add(lbl_dateNtime);
		
		textField_dateNtime = new JTextField();
		textField_dateNtime.setBounds(182, 210, 152, 25);
		textField_dateNtime.setColumns(10);
		panel_createAppointment.add(textField_dateNtime);
		
		//CREATE APPOINTMENT BUTTON
		btnCreateAppointment = new JButton("Create Appointment");
		btnCreateAppointment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "INSERT INTO APPOINTMENTS (AID,CID,VID,DATENTIME) VALUES(?,?,?,?)";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textField_aid.getText());
					pst.setString(2, textField_cid.getText());
					pst.setString(3, textField_vid.getText());
					pst.setString(4, textField_dateNtime.getText());
					pst.execute();

					JOptionPane.showMessageDialog(null, "Appointment Created");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableAppointments();

			}
		});
		btnCreateAppointment.setBounds(98, 396, 188, 38);
		btnCreateAppointment.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
		panel_createAppointment.add(btnCreateAppointment);
		
		//EDIT APPOINTMENT BUTTON
		btnEditAppointment = new JButton("Edit Appointment");
		btnEditAppointment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "UPDATE APPOINTMENTS SET AID='" + textField_aid.getText() + "' ,CID='"
							+ textField_cid.getText() + "' ,VID='" + textField_vid.getText() + "' ,DATENTIME='"
							+ textField_dateNtime.getText() + "' " + "WHERE AID = '" + textField_aid.getText() + "' ";
					PreparedStatement pst = connection.prepareStatement(query);

					pst.execute();

					JOptionPane.showMessageDialog(null, "Appointment Data Updated");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableAppointments();

			}
		});
		btnEditAppointment.setBounds(98, 445, 188, 38);
		btnEditAppointment.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
		panel_createAppointment.add(btnEditAppointment);
		
		//DELETE APPOINTMENT BUTTON
		btnDeleteAppointment = new JButton("Delete Appointment");
		btnDeleteAppointment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "DELETE FROM APPOINTMENTS WHERE AID='" + textField_aid.getText() + "'  ";
					PreparedStatement pst = connection.prepareStatement(query);

					pst.execute();

					JOptionPane.showMessageDialog(null, "Appointment Deleted");

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
				refreshTableAppointments();

			}
		});
		btnDeleteAppointment.setBounds(98, 494, 188, 38);
		btnDeleteAppointment.setFont(new Font("Trebuchet MS", Font.PLAIN, 15));
		panel_createAppointment.add(btnDeleteAppointment);
		
		//JCOMBOBOX BY NAME FOR APPOINTMENTS
		comboBoxByAID_appointments = new JComboBox<String>();
		comboBoxByAID_appointments.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {

					String query = "SELECT * FROM APPOINTMENTS WHERE AID=?";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, (String) comboBoxByAID_appointments.getSelectedItem());
					ResultSet rs = pst.executeQuery();
					while (rs.next()) {
						textField_aid.setText(rs.getString("AID"));
						textField_cid.setText(rs.getString("CID"));
						textField_vid.setText(rs.getString("VID"));
						textField_dateNtime.setText(rs.getString("DATENTIME"));
					}

					pst.close();

				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});
		comboBoxByAID_appointments.setBounds(10, 36, 324, 57);
		panel_createAppointment.add(comboBoxByAID_appointments);

		// JTABLE
		scrollPane_appointments = new JScrollPane();
		scrollPane_appointments.setBounds(344, 36, 777, 282);
		panel_createAppointment.add(scrollPane_appointments);

		table_appointments = new JTable();
		scrollPane_appointments.setViewportView(table_appointments);

		tabbedPane_5 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_3.addTab("ΕΠΕΡΧΟΜΕΝΑ ΡΑΝΤΕΒΟΥ", null, tabbedPane_5, null);

		// ΕΠΙΣΚΕΥΕΣ

		JTabbedPane tabbedPane_4 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.addTab("ΕΠΙΣΚΕΥΕΣ", null, tabbedPane_4, null);

		panel_grammateiaEnvs = new JPanel();
		tabbedPane_4.addTab("ΦΑΚΕΛΟΙ ΕΠΙΣΚΕΥΗΣ", null, panel_grammateiaEnvs, null);
		panel_grammateiaEnvs.setLayout(null);
		
		//JSCROLLPANE & JTABLE DATA
		JScrollPane scrollPane_grammateiaEnvs = new JScrollPane();
		scrollPane_grammateiaEnvs.setBounds(34, 22, 342, 213);
		panel_grammateiaEnvs.add(scrollPane_grammateiaEnvs);
		
		table_envelopes = new JTable();
		scrollPane_grammateiaEnvs.setViewportView(table_envelopes);
		
		JButton btnNewButton = new JButton("ΕΚΤΥΠΩΣΗ ΦΑΚΕΛΟΥ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null, "Ο φάκελος επισκευής εκτυπώνεται από τον εκτυπωτή");
			}
		});
		btnNewButton.setBounds(34, 257, 161, 23);
		panel_grammateiaEnvs.add(btnNewButton);
		
		JButton btnGmail = new JButton("ΑΠΟΣΤΟΛΗ ΜΕ GMAIL");
		btnGmail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Ο φάκελος επισκευής θα σταλθεί μέσω gmail");
			}
		});
		btnGmail.setBounds(197, 257, 179, 23);
		panel_grammateiaEnvs.add(btnGmail);
		
		JButton btnNewButton_1 = new JButton("ΑΠΟΔΟΧΗ ΕΠΙΣΚΕΥΗΣ");
		btnNewButton_1.setBounds(34, 344, 342, 23);
		panel_grammateiaEnvs.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("ΣΥΝΔΕΣΗ ΩΣ ΜΗΧΑΝΙΚΟΣ ΥΠΟΔΟΧΗΣ");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Θα συνδεθείτε ως Μηχανικός Υποδοχής.");
				frame.dispose();
				EntranceMechanicGUI em = new EntranceMechanicGUI();
				em.setVisible(true);
			}
		});
		btnNewButton_2.setBounds(862, 427, 259, 105);
		panel_grammateiaEnvs.add(btnNewButton_2);

		refreshTableCustomers();
		fillComboBoxCustomers();
		refreshTableVehicles();
		fillComboBoxVehicles();
		refreshTableAppointments();
		fillComboBoxAppointments();
		refreshTableEnvelopes();
	}
}
