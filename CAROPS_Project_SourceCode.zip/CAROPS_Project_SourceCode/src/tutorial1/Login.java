package tutorial1;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

public class Login {

	private JFrame frame;
	private int workerSelectorCounter;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	Connection connection = null;
	
	private JTextField textFieldUN;
	private JPasswordField passwordField;
	private JTextField textField_SelectedWorkerLogin;


	public Login() {
		initialize();
		connection = sqliteConnection.dbConnector();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 590, 378);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("Username:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 14));
		lblNewLabel.setBounds(64, 180, 100, 25);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Password:");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Stencil", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(64, 226, 100, 25);
		frame.getContentPane().add(lblNewLabel_1);

		textFieldUN = new JTextField();
		textFieldUN.setBounds(174, 175, 92, 35);
		frame.getContentPane().add(textFieldUN);
		textFieldUN.setColumns(10);

		JButton btnLogin = new JButton("Login");
		btnLogin.setFont(new Font("Stencil", Font.PLAIN, 16));
		btnLogin.setBackground(UIManager.getColor("CheckBox.focus"));
		btnLogin.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {

				try {
					String query = "select * from EmployeeInfo where username=? and password=?";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textFieldUN.getText());
					pst.setString(2, passwordField.getText());
					ResultSet rs = pst.executeQuery();

					int count = 0;
					while (rs.next()) {
						count++;
					}
					if (count == 1 && workerSelectorCounter == 1) {
						JOptionPane.showMessageDialog(null, "Correct Credentials");
						frame.dispose();
						SecretaryGUI emplInfo = new SecretaryGUI();
						emplInfo.setVisible(true);
					} else if (count == 1 && workerSelectorCounter == 2) {
						JOptionPane.showMessageDialog(null, "Correct Credentials");
						frame.dispose();
						EntranceMechanicGUI mechanic1 = new EntranceMechanicGUI();
						mechanic1.setVisible(true);
					} else if (count == 1 && workerSelectorCounter == 3) {
						JOptionPane.showMessageDialog(null, "Correct Credentials");
						frame.dispose();
						SupervisorMechanicGUI mechanic2 = new SupervisorMechanicGUI();
						mechanic2.setVisible(true);
					} else if (count == 1 && workerSelectorCounter == 4) {
						JOptionPane.showMessageDialog(null, "Correct Credentials");
						frame.dispose();
						EmployeeMechanicGUI mechanic3 = new EmployeeMechanicGUI();
						mechanic3.setVisible(true);
					} else if (count == 1 && workerSelectorCounter == 5) {
						JOptionPane.showMessageDialog(null, "Correct Credentials");
						frame.dispose();
						OwnersGUI boss1 = new OwnersGUI();
						boss1.setVisible(true);
					} else if (count > 1) {
						JOptionPane.showMessageDialog(null, "Duplicate Username or Password");
					} else {
						JOptionPane.showMessageDialog(null, "Wrong Credentials");
					}
					rs.close();
					pst.close();
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, e);
				} finally {
					try {

					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, e);
					}
				}
			}
		});
		btnLogin.setBounds(174, 288, 131, 35);
		frame.getContentPane().add(btnLogin);

		passwordField = new JPasswordField();
		passwordField.setBounds(174, 221, 92, 35);
		frame.getContentPane().add(passwordField);

		JButton btnNewButton = new JButton("ΓΡΑΜΜΑΤΕΙΑ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				workerSelectorCounter = 1;
				textField_SelectedWorkerLogin.setText("ΓΡΑΜΜΑΤΕΙΑ");
			}
		});
		btnNewButton.setBounds(10, 56, 141, 23);
		frame.getContentPane().add(btnNewButton);

		JLabel lblNewLabel_2 = new JLabel("Επιλέξτε από τα παρακάτω ως τι θέλετε να συνδεθείτε:");
		lblNewLabel_2.setBounds(10, 11, 300, 33);
		frame.getContentPane().add(lblNewLabel_2);

		JButton btnNewButton_1 = new JButton("ΜΗΧΑΝΙΚΟΣ ΥΠΟΔΟΧΗΣ");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_SelectedWorkerLogin.setText("ΜΗΧΑΝΙΚΟΣ ΥΠΟΔΟΧΗΣ");
				workerSelectorCounter = 2;
			}
		});
		btnNewButton_1.setBounds(161, 56, 186, 23);
		frame.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_1_1 = new JButton("ΕΠΙΒΛΕΠΩΝ ΜΗΧΑΝΙΚΟΣ");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_SelectedWorkerLogin.setText("ΕΠΙΒΛΕΠΩΝ ΜΗΧΑΝΙΚΟΣ");
				workerSelectorCounter = 3;
			}
		});
		btnNewButton_1_1.setBounds(357, 56, 207, 23);
		frame.getContentPane().add(btnNewButton_1_1);

		JButton btnNewButton_1_2 = new JButton("ΥΠΑΛΛΗΛΟΣ ΜΗΧΑΝΙΚΟΣ");
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_SelectedWorkerLogin.setText("ΥΠΑΛΛΗΛΟΣ ΜΗΧΑΝΙΚΟΣ");
				workerSelectorCounter = 4;
			}
		});
		btnNewButton_1_2.setBounds(161, 90, 186, 23);
		frame.getContentPane().add(btnNewButton_1_2);

		JButton btnNewButton_2 = new JButton("ΙΔΙΟΚΤΗΤΕΣ");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_SelectedWorkerLogin.setText("ΙΔΙΟΚΤΗΤΗΣ");
				workerSelectorCounter = 5;
			}
		});
		btnNewButton_2.setBounds(10, 90, 141, 23);
		frame.getContentPane().add(btnNewButton_2);

		String line1 = "*Για τους κωδικούς ανατρέξτε";
		String line2 = " στο έγγραφο ReadMe";
		String line3 = "που έχουμε στο GitHub";
		String labelText = "<html>" + line1 + "<br>" + line2 + "<br>" + line3 + "</html>";
		JLabel lblNewLabel_3 = new JLabel(labelText);
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 10));
		lblNewLabel_3.setBounds(294, 205, 124, 69);
		frame.getContentPane().add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("Επιλέξατε να συνδεθείτε ως:");
		lblNewLabel_4.setBounds(10, 134, 157, 14);
		frame.getContentPane().add(lblNewLabel_4);

		textField_SelectedWorkerLogin = new JTextField();
		textField_SelectedWorkerLogin.setBounds(182, 131, 165, 20);
		frame.getContentPane().add(textField_SelectedWorkerLogin);
		textField_SelectedWorkerLogin.setColumns(10);
	}

}
